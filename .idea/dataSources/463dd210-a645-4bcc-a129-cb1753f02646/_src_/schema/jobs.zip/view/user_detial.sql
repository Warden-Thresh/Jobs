CREATE VIEW user_detial AS
  SELECT
    `jobs`.`user`.`user_id`               AS `user_id`,
    `jobs`.`user`.`sso_id`                AS `sso_id`,
    `jobs`.`user`.`password`              AS `password`,
    `jobs`.`user_role`.`role_id`          AS `role_id`,
    `jobs`.`role`.`role_name`             AS `role_name`,
    `jobs`.`role_permission`.`id`         AS `id`,
    `jobs`.`permission`.`permission_name` AS `permission_name`,
    `jobs`.`user`.`state`                 AS `state`
  FROM ((((`jobs`.`user`
    JOIN `jobs`.`user_role` ON ((`jobs`.`user_role`.`user_id` = `jobs`.`user`.`user_id`))) JOIN `jobs`.`role`
      ON ((`jobs`.`user_role`.`role_id` = `jobs`.`role`.`role_id`))) JOIN `jobs`.`role_permission`
      ON ((`jobs`.`role_permission`.`role_id` = `jobs`.`role`.`role_id`))) JOIN `jobs`.`permission`
      ON ((`jobs`.`role_permission`.`permission_id` = `jobs`.`permission`.`permission_id`)))
  ORDER BY `jobs`.`user`.`user_id`;
