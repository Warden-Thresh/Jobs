CREATE VIEW u AS
  SELECT
    `jobs`.`role`.`role_id`                  AS `role_id`,
    `jobs`.`role_permission`.`permission_id` AS `permission_id`
  FROM (`jobs`.`role_permission`
    JOIN `jobs`.`role` ON ((`jobs`.`role_permission`.`role_id` = `jobs`.`role`.`role_id`)));
